// Chapter Detection Module for Bangla Text
class ChapterDetector {
    constructor() {
        // Bangla chapter patterns
        this.chapterPatterns = [
            // Standard patterns
            /অধ্যায়\s*[০-৯১-৯]+/g,
            /অধ্যায়\s*[০-৯১-৯]+\s*[:：]/g,
            /অধ্যায়\s*[০-৯১-৯]+\s*[-–—]/g,
            
            // With English numbers
            /অধ্যায়\s*[0-9]+/g,
            /অধ্যায়\s*[0-9]+\s*[:：]/g,
            /অধ্যায়\s*[0-9]+\s*[-–—]/g,
            
            // Alternative spellings
            /অধ্যায়\s*[০-৯১-৯]+/g,
            /পাঠ\s*[০-৯১-৯]+/g,
            /পাঠ\s*[0-9]+/g,
            
            // With Roman numerals
            /অধ্যায়\s*[IVX]+/g,
            
            // Chapter with title patterns
            /অধ্যায়\s*[০-৯১-৯0-9]+\s*[:：]\s*[^\n]+/g,
            /পাঠ\s*[০-৯১-৯0-9]+\s*[:：]\s*[^\n]+/g,
        ];
        
        // Bangla number mapping
        this.banglaToEnglish = {
            '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
            '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
        };
        
        this.englishToBangla = {
            '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
            '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
        };
    }
    
    detectChapters(text) {
        if (!text || text.trim().length === 0) {
            return [];
        }
        
        console.log('Starting chapter detection...');
        
        // Find all chapter markers
        const chapterMarkers = this.findChapterMarkers(text);
        
        if (chapterMarkers.length === 0) {
            console.log('No chapter markers found');
            return this.createSingleChapter(text);
        }
        
        console.log(`Found ${chapterMarkers.length} chapter markers`);
        
        // Extract chapters based on markers
        const chapters = this.extractChapters(text, chapterMarkers);
        
        // Clean and validate chapters
        const validChapters = this.validateChapters(chapters);
        
        console.log(`Extracted ${validChapters.length} valid chapters`);
        return validChapters;
    }
    
    findChapterMarkers(text) {
        const markers = [];
        
        this.chapterPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(text)) !== null) {
                const markerText = match[0];
                const position = match.index;
                
                // Extract chapter number
                const chapterNumber = this.extractChapterNumber(markerText);
                
                if (chapterNumber) {
                    markers.push({
                        text: markerText,
                        position: position,
                        number: chapterNumber,
                        fullMatch: match[0]
                    });
                }
            }
        });
        
        // Remove duplicates and sort by position
        const uniqueMarkers = this.removeDuplicateMarkers(markers);
        return uniqueMarkers.sort((a, b) => a.position - b.position);
    }
    
    extractChapterNumber(markerText) {
        // Extract number from chapter marker
        const numberMatch = markerText.match(/[০-৯১-৯0-9IVX]+/);
        if (!numberMatch) return null;
        
        let numberStr = numberMatch[0];
        
        // Convert Bangla numbers to English
        numberStr = this.convertBanglaToEnglish(numberStr);
        
        // Handle Roman numerals
        if (/^[IVX]+$/.test(numberStr)) {
            return this.romanToNumber(numberStr);
        }
        
        // Parse as integer
        const number = parseInt(numberStr);
        return isNaN(number) ? null : number;
    }
    
    convertBanglaToEnglish(text) {
        let converted = text;
        Object.keys(this.banglaToEnglish).forEach(bangla => {
            const english = this.banglaToEnglish[bangla];
            converted = converted.replace(new RegExp(bangla, 'g'), english);
        });
        return converted;
    }
    
    convertEnglishToBangla(text) {
        let converted = text;
        Object.keys(this.englishToBangla).forEach(english => {
            const bangla = this.englishToBangla[english];
            converted = converted.replace(new RegExp(english, 'g'), bangla);
        });
        return converted;
    }
    
    romanToNumber(roman) {
        const romanNumerals = {
            'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000
        };
        
        let result = 0;
        for (let i = 0; i < roman.length; i++) {
            const current = romanNumerals[roman[i]];
            const next = romanNumerals[roman[i + 1]];
            
            if (next && current < next) {
                result += next - current;
                i++; // Skip next character
            } else {
                result += current;
            }
        }
        
        return result;
    }
    
    removeDuplicateMarkers(markers) {
        const seen = new Set();
        return markers.filter(marker => {
            const key = `${marker.number}-${Math.floor(marker.position / 100)}`;
            if (seen.has(key)) {
                return false;
            }
            seen.add(key);
            return true;
        });
    }
    
    extractChapters(text, markers) {
        const chapters = [];
        
        for (let i = 0; i < markers.length; i++) {
            const currentMarker = markers[i];
            const nextMarker = markers[i + 1];
            
            // Determine chapter start and end positions
            const startPos = currentMarker.position;
            const endPos = nextMarker ? nextMarker.position : text.length;
            
            // Extract chapter content
            const chapterText = text.substring(startPos, endPos);
            
            // Extract chapter title
            const title = this.extractChapterTitle(chapterText, currentMarker);
            
            // Clean chapter content
            const content = this.cleanChapterContent(chapterText);
            
            if (content.trim().length > 50) { // Minimum content length
                chapters.push({
                    number: currentMarker.number,
                    title: title,
                    content: content,
                    startPosition: startPos,
                    endPosition: endPos
                });
            }
        }
        
        return chapters;
    }
    
    extractChapterTitle(chapterText, marker) {
        const lines = chapterText.split('\n');
        const firstLine = lines[0] || '';
        
        // Try to extract title from the first line
        let title = firstLine.trim();
        
        // If the first line is just the chapter marker, try the next line
        if (title === marker.text || title.length < 5) {
            title = lines[1] ? lines[1].trim() : '';
        }
        
        // Clean up the title
        title = title.replace(/^[:\-–—\s]+/, '').trim();
        
        // If still no good title, create a default one
        if (!title || title.length < 3) {
            title = `অধ্যায় ${this.convertEnglishToBangla(marker.number.toString())}`;
        }
        
        // Limit title length
        if (title.length > 100) {
            title = title.substring(0, 100) + '...';
        }
        
        return title;
    }
    
    cleanChapterContent(content) {
        // Remove excessive whitespace
        let cleaned = content.replace(/\s+/g, ' ');
        
        // Remove page numbers and headers/footers
        cleaned = cleaned.replace(/^\d+\s*$/gm, ''); // Remove standalone numbers
        cleaned = cleaned.replace(/^পৃষ্ঠা\s*\d+\s*$/gm, ''); // Remove page indicators
        
        // Remove excessive line breaks
        cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
        
        // Trim and return
        return cleaned.trim();
    }
    
    validateChapters(chapters) {
        return chapters.filter(chapter => {
            // Minimum content length
            if (chapter.content.length < 100) {
                return false;
            }
            
            // Must have a title
            if (!chapter.title || chapter.title.length < 3) {
                return false;
            }
            
            // Must have a valid chapter number
            if (!chapter.number || chapter.number < 1 || chapter.number > 50) {
                return false;
            }
            
            return true;
        });
    }
    
    createSingleChapter(text) {
        // If no chapters found, create a single chapter from the entire text
        const cleanedText = this.cleanChapterContent(text);
        
        if (cleanedText.length < 100) {
            return [];
        }
        
        // Try to extract a title from the beginning of the text
        const lines = cleanedText.split('\n');
        let title = 'সম্পূর্ণ বই'; // Default title: "Complete Book"
        
        // Look for a potential title in the first few lines
        for (let i = 0; i < Math.min(5, lines.length); i++) {
            const line = lines[i].trim();
            if (line.length > 5 && line.length < 100 && !line.includes('।')) {
                title = line;
                break;
            }
        }
        
        return [{
            number: 1,
            title: title,
            content: cleanedText,
            startPosition: 0,
            endPosition: text.length
        }];
    }
    
    // Method to detect section headers within chapters
    detectSections(chapterContent) {
        const sectionPatterns = [
            /^[০-৯১-৯0-9]+\.[০-৯১-৯0-9]+\s+[^\n]+/gm, // 1.1 Section
            /^[ক-হ]\)\s+[^\n]+/gm, // ক) Section
            /^[০-৯১-৯0-9]+\)\s+[^\n]+/gm, // 1) Section
        ];
        
        const sections = [];
        
        sectionPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(chapterContent)) !== null) {
                sections.push({
                    title: match[0].trim(),
                    position: match.index
                });
            }
        });
        
        return sections.sort((a, b) => a.position - b.position);
    }
    
    // Method to get chapter statistics
    getChapterStats(chapters) {
        if (!chapters || chapters.length === 0) {
            return null;
        }
        
        const stats = {
            totalChapters: chapters.length,
            averageLength: 0,
            shortestChapter: null,
            longestChapter: null,
            totalWords: 0
        };
        
        let minLength = Infinity;
        let maxLength = 0;
        
        chapters.forEach(chapter => {
            const wordCount = chapter.content.split(/\s+/).length;
            stats.totalWords += wordCount;
            
            if (wordCount < minLength) {
                minLength = wordCount;
                stats.shortestChapter = chapter;
            }
            
            if (wordCount > maxLength) {
                maxLength = wordCount;
                stats.longestChapter = chapter;
            }
        });
        
        stats.averageLength = Math.round(stats.totalWords / chapters.length);
        
        return stats;
    }
}

