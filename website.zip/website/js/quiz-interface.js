// Quiz Interface Module
class QuizInterface {
    constructor() {
        this.questions = [];
        this.currentQuestionIndex = 0;
        this.userAnswers = [];
        this.score = 0;
        this.startTime = null;
        this.endTime = null;
        this.isQuizActive = false;
        
        // Initialize event listeners
        this.initializeEventListeners();
    }
    
    initializeEventListeners() {
        // Quiz navigation buttons
        const prevBtn = document.getElementById('prevQuestion');
        const nextBtn = document.getElementById('nextQuestion');
        const submitBtn = document.getElementById('submitQuiz');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', () => this.previousQuestion());
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => this.nextQuestion());
        }
        
        if (submitBtn) {
            submitBtn.addEventListener('click', () => this.submitQuiz());
        }
        
        // Option selection
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('quiz-option')) {
                this.selectOption(e.target);
            }
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (this.isQuizActive) {
                switch(e.key) {
                    case 'ArrowLeft':
                        e.preventDefault();
                        this.previousQuestion();
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        this.nextQuestion();
                        break;
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                        e.preventDefault();
                        this.selectOptionByNumber(parseInt(e.key) - 1);
                        break;
                    case 'Enter':
                        e.preventDefault();
                        if (this.currentQuestionIndex === this.questions.length - 1) {
                            this.submitQuiz();
                        } else {
                            this.nextQuestion();
                        }
                        break;
                }
            }
        });
    }
    
    startQuiz(questions, chapterTitle) {
        if (!questions || questions.length === 0) {
            throw new Error('কোনো প্রশ্ন পাওয়া যায়নি।');
        }
        
        this.questions = questions;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Array(questions.length).fill(null);
        this.score = 0;
        this.startTime = new Date();
        this.isQuizActive = true;
        
        // Update UI
        this.showQuizPage();
        this.updateChapterTitle(chapterTitle);
        this.displayCurrentQuestion();
        this.updateProgress();
        this.updateNavigationButtons();
        
        console.log(`Quiz started with ${questions.length} questions`);
    }
    
    showQuizPage() {
        // Hide other pages
        document.querySelectorAll('.page').forEach(page => {
            page.style.display = 'none';
        });
        
        // Show quiz page
        const quizPage = document.getElementById('quizPage');
        if (quizPage) {
            quizPage.style.display = 'block';
        }
    }
    
    updateChapterTitle(chapterTitle) {
        const titleElement = document.getElementById('selectedChapterTitle');
        if (titleElement && chapterTitle) {
            titleElement.textContent = chapterTitle;
        }
    }
    
    displayCurrentQuestion() {
        const question = this.questions[this.currentQuestionIndex];
        if (!question) return;
        
        // Update question number
        const questionNumberElement = document.getElementById('questionNumber');
        if (questionNumberElement) {
            const currentNum = this.currentQuestionIndex + 1;
            const total = this.questions.length;
            questionNumberElement.textContent = `${window.languageManager ? window.languageManager.getText('question_number') : 'প্রশ্ন'} ${currentNum}/${total}`;
        }
        
        // Update question text
        const questionTextElement = document.getElementById('questionText');
        if (questionTextElement) {
            questionTextElement.textContent = question.question;
        }
        
        // Update options
        const optionsContainer = document.getElementById('quizOptions');
        if (optionsContainer) {
            optionsContainer.innerHTML = '';
            
            question.options.forEach((option, index) => {
                const optionElement = document.createElement('div');
                optionElement.className = 'quiz-option';
                optionElement.dataset.optionIndex = index;
                
                // Check if this option was previously selected
                if (this.userAnswers[this.currentQuestionIndex] === index) {
                    optionElement.classList.add('selected');
                }
                
                optionElement.innerHTML = `
                    <span class="option-letter">${String.fromCharCode(65 + index)}</span>
                    <span class="option-text">${option}</span>
                `;
                
                optionsContainer.appendChild(optionElement);
            });
        }
    }
    
    selectOption(optionElement) {
        if (!this.isQuizActive) return;
        
        const optionIndex = parseInt(optionElement.dataset.optionIndex);
        
        // Remove previous selection
        const optionsContainer = document.getElementById('quizOptions');
        if (optionsContainer) {
            optionsContainer.querySelectorAll('.quiz-option').forEach(opt => {
                opt.classList.remove('selected');
            });
        }
        
        // Add selection to clicked option
        optionElement.classList.add('selected');
        
        // Store user answer
        this.userAnswers[this.currentQuestionIndex] = optionIndex;
        
        // Update progress
        this.updateProgress();
        
        // Auto-advance after a short delay (optional)
        setTimeout(() => {
            if (this.currentQuestionIndex < this.questions.length - 1) {
                // Uncomment the next line to enable auto-advance
                // this.nextQuestion();
            }
        }, 500);
    }
    
    selectOptionByNumber(optionIndex) {
        const optionsContainer = document.getElementById('quizOptions');
        if (optionsContainer) {
            const optionElement = optionsContainer.querySelector(`[data-option-index="${optionIndex}"]`);
            if (optionElement) {
                this.selectOption(optionElement);
            }
        }
    }
    
    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.displayCurrentQuestion();
            this.updateNavigationButtons();
        }
    }
    
    nextQuestion() {
        if (this.currentQuestionIndex < this.questions.length - 1) {
            this.currentQuestionIndex++;
            this.displayCurrentQuestion();
            this.updateNavigationButtons();
        }
    }
    
    updateNavigationButtons() {
        const prevBtn = document.getElementById('prevQuestion');
        const nextBtn = document.getElementById('nextQuestion');
        const submitBtn = document.getElementById('submitQuiz');
        
        if (prevBtn) {
            prevBtn.disabled = this.currentQuestionIndex === 0;
        }
        
        if (nextBtn && submitBtn) {
            if (this.currentQuestionIndex === this.questions.length - 1) {
                nextBtn.style.display = 'none';
                submitBtn.style.display = 'inline-block';
            } else {
                nextBtn.style.display = 'inline-block';
                submitBtn.style.display = 'none';
            }
        }
    }
    
    updateProgress() {
        const answeredCount = this.userAnswers.filter(answer => answer !== null).length;
        const totalCount = this.questions.length;
        const percentage = (answeredCount / totalCount) * 100;
        
        // Update progress bar
        const progressBar = document.getElementById('quizProgressBar');
        if (progressBar) {
            progressBar.style.width = `${percentage}%`;
        }
        
        // Update progress text
        const progressText = document.getElementById('quizProgressText');
        if (progressText) {
            progressText.textContent = `${answeredCount}/${totalCount}`;
        }
    }
    
    submitQuiz() {
        if (!this.isQuizActive) return;
        
        // Check if all questions are answered
        const unansweredCount = this.userAnswers.filter(answer => answer === null).length;
        
        if (unansweredCount > 0) {
            const confirmSubmit = confirm(
                window.languageManager 
                    ? `${unansweredCount}টি প্রশ্নের উত্তর দেওয়া হয়নি। আপনি কি নিশ্চিত যে জমা দিতে চান?`
                    : `${unansweredCount} questions are unanswered. Are you sure you want to submit?`
            );
            
            if (!confirmSubmit) {
                return;
            }
        }
        
        this.endTime = new Date();
        this.isQuizActive = false;
        
        // Calculate score
        this.calculateScore();
        
        // Show results
        this.showResults();
    }
    
    calculateScore() {
        this.score = 0;
        
        this.questions.forEach((question, index) => {
            const userAnswer = this.userAnswers[index];
            if (userAnswer !== null && userAnswer === question.correctAnswer) {
                this.score++;
            }
        });
    }
    
    showResults() {
        // Hide quiz page
        const quizPage = document.getElementById('quizPage');
        if (quizPage) {
            quizPage.style.display = 'none';
        }
        
        // Show results page
        const resultsPage = document.getElementById('resultsPage');
        if (resultsPage) {
            resultsPage.style.display = 'block';
        }
        
        // Update results
        this.displayResults();
    }
    
    displayResults() {
        const percentage = Math.round((this.score / this.questions.length) * 100);
        const timeTaken = this.endTime - this.startTime;
        const minutes = Math.floor(timeTaken / 60000);
        const seconds = Math.floor((timeTaken % 60000) / 1000);
        
        // Update score display
        const scoreElement = document.getElementById('finalScore');
        if (scoreElement) {
            scoreElement.textContent = `${this.score}/${this.questions.length} (${percentage}%)`;
        }
        
        // Update performance message
        const performanceElement = document.getElementById('performanceMessage');
        if (performanceElement && window.languageManager) {
            performanceElement.textContent = window.languageManager.getPerformanceMessage(percentage);
        }
        
        // Update time taken
        const timeElement = document.getElementById('timeTaken');
        if (timeElement) {
            timeElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
        
        // Display detailed results
        this.displayDetailedResults();
    }
    
    displayDetailedResults() {
        const reviewContainer = document.getElementById('answerReview');
        if (!reviewContainer) return;
        
        reviewContainer.innerHTML = '';
        
        this.questions.forEach((question, index) => {
            const userAnswer = this.userAnswers[index];
            const isCorrect = userAnswer === question.correctAnswer;
            
            const reviewItem = document.createElement('div');
            reviewItem.className = `review-item ${isCorrect ? 'correct' : 'incorrect'}`;
            
            let userAnswerText = userAnswer !== null ? question.options[userAnswer] : 'উত্তর দেওয়া হয়নি';
            let correctAnswerText = question.options[question.correctAnswer];
            
            reviewItem.innerHTML = `
                <div class="review-question">
                    <h4>প্রশ্ন ${index + 1}: ${question.question}</h4>
                </div>
                <div class="review-answers">
                    <div class="user-answer ${isCorrect ? 'correct' : 'incorrect'}">
                        <strong>${window.languageManager ? window.languageManager.getText('your_answer') : 'আপনার উত্তর:'}</strong> ${userAnswerText}
                    </div>
                    ${!isCorrect ? `
                        <div class="correct-answer">
                            <strong>${window.languageManager ? window.languageManager.getText('correct_answer') : 'সঠিক উত্তর:'}</strong> ${correctAnswerText}
                        </div>
                    ` : ''}
                </div>
            `;
            
            reviewContainer.appendChild(reviewItem);
        });
    }
    
    // Method to restart quiz with same questions
    restartQuiz() {
        this.currentQuestionIndex = 0;
        this.userAnswers = new Array(this.questions.length).fill(null);
        this.score = 0;
        this.startTime = new Date();
        this.isQuizActive = true;
        
        this.showQuizPage();
        this.displayCurrentQuestion();
        this.updateProgress();
        this.updateNavigationButtons();
    }
    
    // Method to go back to chapter selection
    selectNewChapter() {
        this.isQuizActive = false;
        this.questions = [];
        this.userAnswers = [];
        
        // Show chapter page
        document.querySelectorAll('.page').forEach(page => {
            page.style.display = 'none';
        });
        
        const chapterPage = document.getElementById('chapterPage');
        if (chapterPage) {
            chapterPage.style.display = 'block';
        }
    }
    
    // Method to start over with new file
    startOver() {
        this.isQuizActive = false;
        this.questions = [];
        this.userAnswers = [];
        
        // Show landing page
        document.querySelectorAll('.page').forEach(page => {
            page.style.display = 'none';
        });
        
        const landingPage = document.getElementById('landingPage');
        if (landingPage) {
            landingPage.style.display = 'block';
        }
        
        // Reset application state if needed
        if (window.app && window.app.reset) {
            window.app.reset();
        }
    }
    
    // Method to get quiz statistics
    getQuizStats() {
        if (!this.endTime || !this.startTime) {
            return null;
        }
        
        const timeTaken = this.endTime - this.startTime;
        const percentage = Math.round((this.score / this.questions.length) * 100);
        const answeredCount = this.userAnswers.filter(answer => answer !== null).length;
        
        return {
            score: this.score,
            totalQuestions: this.questions.length,
            percentage: percentage,
            timeTaken: timeTaken,
            answeredCount: answeredCount,
            unansweredCount: this.questions.length - answeredCount
        };
    }
}

