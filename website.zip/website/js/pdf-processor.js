// PDF Processing Module
class PDFProcessor {
    constructor() {
        this.pdf = null;
        this.pages = [];
    }
    
    async loadPDF(file) {
        try {
            const arrayBuffer = await file.arrayBuffer();
            this.pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            console.log(`PDF loaded: ${this.pdf.numPages} pages`);
            return this.pdf;
        } catch (error) {
            console.error('Error loading PDF:', error);
            throw new Error('PDF লোড করতে সমস্যা হয়েছে।');
        }
    }
    
    async convertPagesToImages(progressCallback) {
        if (!this.pdf) {
            throw new Error('PDF not loaded');
        }
        
        const images = [];
        const totalPages = this.pdf.numPages;
        
        for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
            try {
                const page = await this.pdf.getPage(pageNum);
                const canvas = await this.renderPageToCanvas(page);
                images.push(canvas);
                
                if (progressCallback) {
                    progressCallback(pageNum / totalPages);
                }
            } catch (error) {
                console.error(`Error processing page ${pageNum}:`, error);
                // Continue with other pages even if one fails
            }
        }
        
        this.pages = images;
        return images;
    }
    
    async renderPageToCanvas(page) {
        const scale = 2.0; // Higher scale for better OCR accuracy
        const viewport = page.getViewport({ scale });
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        const renderContext = {
            canvasContext: context,
            viewport: viewport
        };
        
        await page.render(renderContext).promise;
        return canvas;
    }
    
    async extractTextFromPage(pageNum) {
        if (!this.pdf) {
            throw new Error('PDF not loaded');
        }
        
        try {
            const page = await this.pdf.getPage(pageNum);
            const textContent = await page.getTextContent();
            
            let text = '';
            textContent.items.forEach(item => {
                text += item.str + ' ';
            });
            
            return text.trim();
        } catch (error) {
            console.error(`Error extracting text from page ${pageNum}:`, error);
            return '';
        }
    }
    
    async extractAllText() {
        if (!this.pdf) {
            throw new Error('PDF not loaded');
        }
        
        let fullText = '';
        const totalPages = this.pdf.numPages;
        
        for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
            const pageText = await this.extractTextFromPage(pageNum);
            fullText += pageText + '\n\n';
        }
        
        return fullText.trim();
    }
    
    getPageCount() {
        return this.pdf ? this.pdf.numPages : 0;
    }
    
    getPageImages() {
        return this.pages;
    }
    
    // Helper method to check if PDF has extractable text
    async hasExtractableText() {
        if (!this.pdf || this.pdf.numPages === 0) {
            return false;
        }
        
        try {
            // Check first few pages for text content
            const pagesToCheck = Math.min(3, this.pdf.numPages);
            let totalTextLength = 0;
            
            for (let pageNum = 1; pageNum <= pagesToCheck; pageNum++) {
                const pageText = await this.extractTextFromPage(pageNum);
                totalTextLength += pageText.length;
            }
            
            // If we found significant text content, PDF has extractable text
            return totalTextLength > 100;
        } catch (error) {
            console.error('Error checking extractable text:', error);
            return false;
        }
    }
    
    // Method to get PDF metadata
    async getMetadata() {
        if (!this.pdf) {
            return null;
        }
        
        try {
            const metadata = await this.pdf.getMetadata();
            return {
                title: metadata.info.Title || '',
                author: metadata.info.Author || '',
                subject: metadata.info.Subject || '',
                creator: metadata.info.Creator || '',
                producer: metadata.info.Producer || '',
                creationDate: metadata.info.CreationDate || '',
                modificationDate: metadata.info.ModDate || '',
                pages: this.pdf.numPages
            };
        } catch (error) {
            console.error('Error getting PDF metadata:', error);
            return null;
        }
    }
    
    // Method to optimize canvas for OCR
    optimizeCanvasForOCR(canvas) {
        const context = canvas.getContext('2d');
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        
        // Convert to grayscale and increase contrast
        for (let i = 0; i < data.length; i += 4) {
            const gray = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
            
            // Increase contrast
            const contrast = 1.5;
            const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
            const enhancedGray = Math.min(255, Math.max(0, factor * (gray - 128) + 128));
            
            data[i] = enhancedGray;     // Red
            data[i + 1] = enhancedGray; // Green
            data[i + 2] = enhancedGray; // Blue
            // Alpha channel remains unchanged
        }
        
        context.putImageData(imageData, 0, 0);
        return canvas;
    }
}

