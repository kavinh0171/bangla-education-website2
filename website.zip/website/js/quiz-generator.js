// Quiz Generator Module with Gemini API Integration
class QuizGenerator {
    constructor() {
        // Get API key from configuration
        this.apiKey = window.CONFIG ? window.CONFIG.GEMINI_API_KEY : 'YOUR_GEMINI_API_KEY_HERE';
        this.apiUrl = window.CONFIG ? window.CONFIG.GEMINI_API_URL : 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
        this.maxRetries = window.CONFIG ? window.CONFIG.MAX_RETRIES : 3;
        this.retryDelay = window.CONFIG ? window.CONFIG.RETRY_DELAY : 1000;
    }
    
    async generateQuestions(chapterContent, questionCount = 10) {
        if (!chapterContent || chapterContent.trim().length < 100) {
            throw new Error('অধ্যায়ের বিষয়বস্তু যথেষ্ট নয়।');
        }
        
        if (!this.apiKey || this.apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            // For demo purposes, return sample questions
            return this.generateSampleQuestions(questionCount);
        }
        
        try {
            console.log(`Generating ${questionCount} questions for chapter content...`);
            
            const prompt = this.createPrompt(chapterContent, questionCount);
            const response = await this.callGeminiAPI(prompt);
            const questions = this.parseResponse(response);
            
            if (!questions || questions.length === 0) {
                throw new Error('No questions generated');
            }
            
            console.log(`Successfully generated ${questions.length} questions`);
            return questions.slice(0, questionCount); // Ensure we don't exceed requested count
            
        } catch (error) {
            console.error('Error generating questions:', error);
            
            // Fallback to sample questions if API fails
            console.log('Falling back to sample questions...');
            return this.generateSampleQuestions(questionCount);
        }
    }
    
    createPrompt(chapterContent, questionCount) {
        // Truncate content if too long (Gemini has token limits)
        const maxContentLength = 8000; // Conservative limit
        const truncatedContent = chapterContent.length > maxContentLength 
            ? chapterContent.substring(0, maxContentLength) + '...'
            : chapterContent;
        
        return `আপনি একজন বাংলা শিক্ষক। নিচের অধ্যায়ের বিষয়বস্তু থেকে ${questionCount}টি বহুনির্বাচনী প্রশ্ন (MCQ) তৈরি করুন।

নির্দেশনা:
1. প্রতিটি প্রশ্নের ৪টি বিকল্প উত্তর থাকবে (ক, খ, গ, ঘ)
2. শুধুমাত্র একটি সঠিক উত্তর থাকবে
3. প্রশ্নগুলো অধ্যায়ের মূল বিষয়বস্তুর উপর ভিত্তি করে হতে হবে
4. প্রশ্ন ও উত্তর সবকিছু বাংলায় লিখুন
5. প্রশ্নগুলো বিভিন্ন কঠিনতার মাত্রার হতে পারে

উত্তরের ফরম্যাট:
```json
[
  {
    "question": "প্রশ্ন এখানে লিখুন",
    "options": ["ক) প্রথম বিকল্প", "খ) দ্বিতীয় বিকল্প", "গ) তৃতীয় বিকল্প", "ঘ) চতুর্থ বিকল্প"],
    "correctAnswer": 0
  }
]
```

অধ্যায়ের বিষয়বস্তু:
${truncatedContent}

অনুগ্রহ করে শুধুমাত্র JSON ফরম্যাটে উত্তর দিন, অন্য কোনো টেক্সট যোগ করবেন না।`;
    }
    
    async callGeminiAPI(prompt) {
        const requestBody = {
            contents: [{
                parts: [{
                    text: prompt
                }]
            }],
            generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 2048,
            },
            safetySettings: [
                {
                    category: "HARM_CATEGORY_HARASSMENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_HATE_SPEECH",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                }
            ]
        };
        
        for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
            try {
                const response = await fetch(`${this.apiUrl}?key=${this.apiKey}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(requestBody)
                });
                
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(`API Error: ${response.status} - ${errorData.error?.message || response.statusText}`);
                }
                
                const data = await response.json();
                
                if (!data.candidates || data.candidates.length === 0) {
                    throw new Error('No response from API');
                }
                
                const content = data.candidates[0].content;
                if (!content || !content.parts || content.parts.length === 0) {
                    throw new Error('Empty response from API');
                }
                
                return content.parts[0].text;
                
            } catch (error) {
                console.error(`API call attempt ${attempt} failed:`, error);
                
                if (attempt === this.maxRetries) {
                    throw error;
                }
                
                // Wait before retrying
                await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
            }
        }
    }
    
    parseResponse(response) {
        try {
            // Clean the response to extract JSON
            let cleanedResponse = response.trim();
            
            // Remove markdown code blocks if present
            cleanedResponse = cleanedResponse.replace(/```json\s*/g, '');
            cleanedResponse = cleanedResponse.replace(/```\s*/g, '');
            
            // Find JSON array in the response
            const jsonMatch = cleanedResponse.match(/\[[\s\S]*\]/);
            if (!jsonMatch) {
                throw new Error('No JSON array found in response');
            }
            
            const jsonString = jsonMatch[0];
            const questions = JSON.parse(jsonString);
            
            // Validate and clean questions
            return this.validateQuestions(questions);
            
        } catch (error) {
            console.error('Error parsing API response:', error);
            console.log('Raw response:', response);
            throw new Error('প্রশ্ন পার্স করতে সমস্যা হয়েছে।');
        }
    }
    
    validateQuestions(questions) {
        if (!Array.isArray(questions)) {
            throw new Error('Response is not an array');
        }
        
        const validQuestions = [];
        
        questions.forEach((q, index) => {
            try {
                // Validate question structure
                if (!q.question || typeof q.question !== 'string') {
                    console.warn(`Question ${index + 1}: Invalid question text`);
                    return;
                }
                
                if (!Array.isArray(q.options) || q.options.length !== 4) {
                    console.warn(`Question ${index + 1}: Invalid options`);
                    return;
                }
                
                if (typeof q.correctAnswer !== 'number' || q.correctAnswer < 0 || q.correctAnswer > 3) {
                    console.warn(`Question ${index + 1}: Invalid correct answer`);
                    return;
                }
                
                // Clean and format the question
                const cleanedQuestion = {
                    question: q.question.trim(),
                    options: q.options.map(option => {
                        // Remove option labels if they exist (ক), খ), etc.)
                        return option.replace(/^[ক-ঘকখগঘ]\)\s*/, '').trim();
                    }),
                    correctAnswer: q.correctAnswer
                };
                
                validQuestions.push(cleanedQuestion);
                
            } catch (error) {
                console.warn(`Error validating question ${index + 1}:`, error);
            }
        });
        
        return validQuestions;
    }
    
    generateSampleQuestions(questionCount) {
        // Sample questions for demonstration when API is not available
        const sampleQuestions = [
            {
                question: "বাংলাদেশের রাজধানী কোনটি?",
                options: ["ঢাকা", "চট্টগ্রাম", "সিলেট", "রাজশাহী"],
                correctAnswer: 0
            },
            {
                question: "বাংলা ভাষার উৎপত্তি কোন ভাষা থেকে?",
                options: ["সংস্কৃত", "পালি", "প্রাকৃত", "অপভ্রংশ"],
                correctAnswer: 3
            },
            {
                question: "একুশে ফেব্রুয়ারি কোন দিবস?",
                options: ["স্বাধীনতা দিবস", "বিজয় দিবস", "শহীদ দিবস", "জাতীয় দিবস"],
                correctAnswer: 2
            },
            {
                question: "বাংলাদেশের জাতীয় ফুল কোনটি?",
                options: ["গোলাপ", "শাপলা", "জুঁই", "বেলি"],
                correctAnswer: 1
            },
            {
                question: "বাংলা সাহিত্যের আদি নিদর্শন কোনটি?",
                options: ["চর্যাপদ", "মনসামঙ্গল", "রামায়ণ", "মহাভারত"],
                correctAnswer: 0
            },
            {
                question: "বাংলাদেশের সবচেয়ে বড় নদী কোনটি?",
                options: ["পদ্মা", "মেঘনা", "যমুনা", "ব্রহ্মপুত্র"],
                correctAnswer: 0
            },
            {
                question: "বাংলা বর্ণমালায় মোট কতটি বর্ণ আছে?",
                options: ["৪৮টি", "৪৯টি", "৫০টি", "৫১টি"],
                correctAnswer: 2
            },
            {
                question: "বাংলাদেশের জাতীয় কবি কে?",
                options: ["রবীন্দ্রনাথ ঠাকুর", "কাজী নজরুল ইসলাম", "জীবনানন্দ দাশ", "মাইকেল মধুসূদন দত্ত"],
                correctAnswer: 1
            },
            {
                question: "বাংলাদেশের মুক্তিযুদ্ধ কত সালে হয়েছিল?",
                options: ["১৯৭০", "১৯৭১", "১৯৭২", "১৯৭৩"],
                correctAnswer: 1
            },
            {
                question: "বাংলা ভাষায় স্বরবর্ণ কতটি?",
                options: ["৯টি", "১০টি", "১১টি", "১২টি"],
                correctAnswer: 2
            }
        ];
        
        // Shuffle and return requested number of questions
        const shuffled = this.shuffleArray([...sampleQuestions]);
        return shuffled.slice(0, Math.min(questionCount, shuffled.length));
    }
    
    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    
    // Method to set API key (for configuration)
    setApiKey(apiKey) {
        this.apiKey = apiKey;
    }
    
    // Method to test API connectivity
    async testAPI() {
        if (!this.apiKey || this.apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            return { success: false, message: 'API key not configured' };
        }
        
        try {
            const testPrompt = "বাংলায় একটি সহজ প্রশ্ন লিখুন।";
            const response = await this.callGeminiAPI(testPrompt);
            return { success: true, message: 'API connection successful', response };
        } catch (error) {
            return { success: false, message: error.message };
        }
    }
    
    // Method to generate questions with different difficulty levels
    async generateQuestionsByDifficulty(chapterContent, easyCount = 3, mediumCount = 4, hardCount = 3) {
        const difficulties = [
            { level: 'সহজ', count: easyCount, description: 'মূল তথ্য ও সংজ্ঞা ভিত্তিক' },
            { level: 'মাধ্যম', count: mediumCount, description: 'বিশ্লেষণ ও প্রয়োগ ভিত্তিক' },
            { level: 'কঠিন', count: hardCount, description: 'সংশ্লেষণ ও মূল্যায়ন ভিত্তিক' }
        ];
        
        const allQuestions = [];
        
        for (const difficulty of difficulties) {
            if (difficulty.count > 0) {
                const prompt = this.createDifficultyPrompt(chapterContent, difficulty.count, difficulty.level, difficulty.description);
                try {
                    const response = await this.callGeminiAPI(prompt);
                    const questions = this.parseResponse(response);
                    allQuestions.push(...questions);
                } catch (error) {
                    console.error(`Error generating ${difficulty.level} questions:`, error);
                }
            }
        }
        
        return allQuestions.length > 0 ? allQuestions : this.generateSampleQuestions(easyCount + mediumCount + hardCount);
    }
    
    createDifficultyPrompt(chapterContent, questionCount, difficulty, description) {
        const maxContentLength = 8000;
        const truncatedContent = chapterContent.length > maxContentLength 
            ? chapterContent.substring(0, maxContentLength) + '...'
            : chapterContent;
        
        return `আপনি একজন বাংলা শিক্ষক। নিচের অধ্যায়ের বিষয়বস্তু থেকে ${questionCount}টি ${difficulty} মানের বহুনির্বাচনী প্রশ্ন (MCQ) তৈরি করুন।

${difficulty} প্রশ্নের বৈশিষ্ট্য: ${description}

নির্দেশনা:
1. প্রতিটি প্রশ্নের ৪টি বিকল্প উত্তর থাকবে
2. শুধুমাত্র একটি সঠিক উত্তর থাকবে
3. প্রশ্নগুলো ${difficulty} মানের হতে হবে
4. প্রশ্ন ও উত্তর সবকিছু বাংলায় লিখুন

উত্তরের ফরম্যাট:
```json
[
  {
    "question": "প্রশ্ন এখানে লিখুন",
    "options": ["প্রথম বিকল্প", "দ্বিতীয় বিকল্প", "তৃতীয় বিকল্প", "চতুর্থ বিকল্প"],
    "correctAnswer": 0
  }
]
```

অধ্যায়ের বিষয়বস্তু:
${truncatedContent}

অনুগ্রহ করে শুধুমাত্র JSON ফরম্যাটে উত্তর দিন।`;
    }
}

