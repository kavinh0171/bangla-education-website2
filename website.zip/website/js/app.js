// Main Application Controller
class BanglaEducationApp {
    constructor() {
        this.currentPage = 'landingPage';
        this.currentLanguage = 'bn';
        this.uploadedFile = null;
        this.extractedText = '';
        this.chapters = [];
        this.currentChapter = null;
        this.questions = [];
        this.currentQuestionIndex = 0;
        this.userAnswers = [];
        this.quizStartTime = null;
        
        // Initialize processors and interfaces
        this.pdfProcessor = null;
        this.ocrProcessor = null;
        this.chapterDetector = null;
        this.quizGenerator = null;
        this.quizInterface = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupPDFWorker();
        this.initializeProcessors();
        this.showPage('landingPage');
        console.log('Bangla Education App initialized');
    }
    
    initializeProcessors() {
        // Initialize processors when needed to avoid dependency issues
        try {
            if (typeof PDFProcessor !== 'undefined') {
                this.pdfProcessor = new PDFProcessor();
            }
            if (typeof OCRProcessor !== 'undefined') {
                this.ocrProcessor = new OCRProcessor();
            }
            if (typeof ChapterDetector !== 'undefined') {
                this.chapterDetector = new ChapterDetector();
            }
            if (typeof QuizGenerator !== 'undefined') {
                this.quizGenerator = new QuizGenerator();
            }
            if (typeof QuizInterface !== 'undefined') {
                this.quizInterface = new QuizInterface();
            }
        } catch (error) {
            console.warn('Some processors could not be initialized:', error);
        }
    }
    
    setupEventListeners() {
        // File upload
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        
        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
        uploadArea.addEventListener('dragleave', this.handleDragLeave.bind(this));
        uploadArea.addEventListener('drop', this.handleDrop.bind(this));
        fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        
        // Language toggle
        document.getElementById('langToggle').addEventListener('click', this.toggleLanguage.bind(this));
        
        // Navigation buttons
        document.getElementById('cancelBtn').addEventListener('click', () => this.showPage('landingPage'));
        document.getElementById('backToUpload').addEventListener('click', () => this.showPage('landingPage'));
        
        // Quiz navigation
        document.getElementById('prevBtn').addEventListener('click', this.previousQuestion.bind(this));
        document.getElementById('nextBtn').addEventListener('click', this.nextQuestion.bind(this));
        document.getElementById('submitQuiz').addEventListener('click', this.submitQuiz.bind(this));
        
        // Results actions
        document.getElementById('reviewAnswers').addEventListener('click', this.showAnswerReview.bind(this));
        document.getElementById('tryAgain').addEventListener('click', this.retakeQuiz.bind(this));
        document.getElementById('newChapter').addEventListener('click', () => this.showPage('chapterPage'));
    }
    
    setupPDFWorker() {
        // Configure PDF.js worker
        if (typeof pdfjsLib !== 'undefined') {
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        }
    }
    
    showPage(pageId) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        // Show target page
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
            this.currentPage = pageId;
        }
    }
    
    toggleLanguage() {
        this.currentLanguage = this.currentLanguage === 'bn' ? 'en' : 'bn';
        this.updateLanguage();
    }
    
    updateLanguage() {
        const elements = document.querySelectorAll('[data-bn][data-en]');
        elements.forEach(element => {
            const text = this.currentLanguage === 'bn' ? element.dataset.bn : element.dataset.en;
            element.textContent = text;
        });
        
        // Update language toggle button
        const langBtn = document.getElementById('langToggle');
        langBtn.textContent = this.currentLanguage === 'bn' ? 'English' : 'বাংলা';
    }
    
    // File handling methods
    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    }
    
    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.processFile(file);
        }
    }
    
    async processFile(file) {
        // Validate file
        if (!file.type.includes('pdf')) {
            this.showError('অনুগ্রহ করে একটি PDF ফাইল নির্বাচন করুন।');
            return;
        }
        
        if (file.size > 50 * 1024 * 1024) { // 50MB limit
            this.showError('ফাইলের আকার ৫০MB এর চেয়ে ছোট হতে হবে।');
            return;
        }
        
        this.uploadedFile = file;
        this.showPage('processingPage');
        
        try {
            // Process PDF and extract text
            await this.processPDF(file);
        } catch (error) {
            console.error('Error processing file:', error);
            this.showError('ফাইল প্রক্রিয়াকরণে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
            this.showPage('landingPage');
        }
    }
    
    async processPDF(file) {
        this.updateProcessingStatus('PDF ফাইল পড়া হচ্ছে...', 0, 'step1');
        
        // Load PDF
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
        
        this.updateProcessingStatus('টেক্সট নিষ্কাশন করা হচ্ছে...', 20, 'step2');
        
        // Extract text using OCR
        const ocrProcessor = new OCRProcessor();
        this.extractedText = await ocrProcessor.processPDF(pdf, (progress) => {
            this.updateProcessingStatus('টেক্সট নিষ্কাশন করা হচ্ছে...', 20 + (progress * 0.6), 'step2');
        });
        
        this.updateProcessingStatus('অধ্যায় খুঁজে বের করা হচ্ছে...', 80, 'step3');
        
        // Detect chapters
        const chapterDetector = new ChapterDetector();
        this.chapters = chapterDetector.detectChapters(this.extractedText);
        
        this.updateProcessingStatus('সম্পন্ন!', 100, 'step3');
        
        // Show chapter selection page
        setTimeout(() => {
            this.displayChapters();
            this.showPage('chapterPage');
        }, 1000);
    }
    
    updateProcessingStatus(message, progress, activeStep) {
        document.getElementById('processingStatus').textContent = message;
        document.getElementById('progressPercent').textContent = Math.round(progress) + '%';
        
        // Update progress circle
        const circle = document.querySelector('.progress-ring-circle');
        const circumference = 2 * Math.PI * 54; // radius = 54
        const offset = circumference - (progress / 100) * circumference;
        circle.style.strokeDashoffset = offset;
        
        if (progress > 0) {
            circle.classList.add('active');
        }
        
        // Update step indicators
        document.querySelectorAll('.step').forEach(step => {
            step.classList.remove('active', 'completed');
        });
        
        const currentStep = document.getElementById(activeStep);
        if (currentStep) {
            currentStep.classList.add('active');
        }
        
        // Mark previous steps as completed
        const stepOrder = ['step1', 'step2', 'step3'];
        const currentIndex = stepOrder.indexOf(activeStep);
        for (let i = 0; i < currentIndex; i++) {
            document.getElementById(stepOrder[i]).classList.add('completed');
        }
    }
    
    displayChapters() {
        const chapterList = document.getElementById('chapterList');
        const chapterCount = document.getElementById('chapterCount');
        
        chapterCount.textContent = `মোট অধ্যায়: ${this.chapters.length}`;
        chapterList.innerHTML = '';
        
        if (this.chapters.length === 0) {
            chapterList.innerHTML = `
                <div class="no-chapters">
                    <p>কোনো অধ্যায় পাওয়া যায়নি। অনুগ্রহ করে নিশ্চিত করুন যে আপনার PDF ফাইলে "অধ্যায় ১", "অধ্যায় ২" ইত্যাদি শিরোনাম রয়েছে।</p>
                </div>
            `;
            return;
        }
        
        this.chapters.forEach((chapter, index) => {
            const chapterCard = document.createElement('div');
            chapterCard.className = 'chapter-card';
            chapterCard.innerHTML = `
                <h3 class="chapter-title">${chapter.title}</h3>
                <p class="chapter-preview-text">${chapter.content.substring(0, 200)}...</p>
                <div class="chapter-actions-card">
                    <button class="btn btn-primary generate-mcq-btn" data-chapter-index="${index}">
                        প্রশ্ন তৈরি করুন
                    </button>
                    <button class="btn btn-outline preview-btn" data-chapter-index="${index}">
                        পূর্বরূপ
                    </button>
                </div>
            `;
            
            chapterList.appendChild(chapterCard);
        });
        
        // Add event listeners for chapter actions
        document.querySelectorAll('.generate-mcq-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const chapterIndex = parseInt(e.target.dataset.chapterIndex);
                this.generateMCQ(chapterIndex);
            });
        });
        
        document.querySelectorAll('.preview-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const chapterIndex = parseInt(e.target.dataset.chapterIndex);
                this.previewChapter(chapterIndex);
            });
        });
    }
    
    previewChapter(chapterIndex) {
        const chapter = this.chapters[chapterIndex];
        const previewContent = document.getElementById('previewContent');
        
        // Remove selection from all cards
        document.querySelectorAll('.chapter-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Select current card
        document.querySelectorAll('.chapter-card')[chapterIndex].classList.add('selected');
        
        previewContent.innerHTML = `
            <h4>${chapter.title}</h4>
            <div style="line-height: 1.8; white-space: pre-wrap;">${chapter.content}</div>
        `;
    }
    
    async generateMCQ(chapterIndex) {
        this.currentChapter = this.chapters[chapterIndex];
        this.showPage('quizGenPage');
        
        // Update selected chapter display
        document.getElementById('selectedChapter').textContent = 
            `নির্বাচিত অধ্যায়: ${this.currentChapter.title}`;
        
        try {
            // Use the new quiz generator if available, otherwise fallback to inline
            const quizGenerator = this.quizGenerator || new QuizGenerator();
            const questionCount = parseInt(document.getElementById('questionCount').value) || 10;
            
            this.questions = await quizGenerator.generateQuestions(
                this.currentChapter.content, 
                questionCount
            );
            
            if (this.questions && this.questions.length > 0) {
                // Use new QuizInterface if available
                if (this.quizInterface) {
                    this.quizInterface.startQuiz(this.questions, this.currentChapter.title);
                } else {
                    this.startQuiz();
                }
            } else {
                throw new Error('No questions generated');
            }
        } catch (error) {
            console.error('Error generating MCQ:', error);
            this.showError('প্রশ্ন তৈরিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
            this.showPage('chapterPage');
        }
    }
    
    startQuiz() {
        this.currentQuestionIndex = 0;
        this.userAnswers = new Array(this.questions.length).fill(null);
        this.quizStartTime = Date.now();
        
        this.showPage('quizPage');
        this.displayQuestion();
    }
    
    displayQuestion() {
        const question = this.questions[this.currentQuestionIndex];
        const questionNumber = document.getElementById('questionNumber');
        const questionText = document.getElementById('questionText');
        const optionsContainer = document.getElementById('optionsContainer');
        const progressFill = document.getElementById('progressFill');
        
        // Update question number and progress
        questionNumber.textContent = `প্রশ্ন ${this.currentQuestionIndex + 1}/${this.questions.length}`;
        const progressPercent = ((this.currentQuestionIndex + 1) / this.questions.length) * 100;
        progressFill.style.width = progressPercent + '%';
        
        // Display question
        questionText.textContent = question.question;
        
        // Display options
        optionsContainer.innerHTML = '';
        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.innerHTML = `
                <div class="option-label">${String.fromCharCode(65 + index)}</div>
                <div class="option-text">${option}</div>
            `;
            
            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });
        
        // Restore previous selection if any
        if (this.userAnswers[this.currentQuestionIndex] !== null) {
            this.selectOption(this.userAnswers[this.currentQuestionIndex], false);
        }
        
        // Update navigation buttons
        this.updateQuizNavigation();
    }
    
    selectOption(optionIndex, updateAnswer = true) {
        // Remove previous selection
        document.querySelectorAll('.option').forEach(option => {
            option.classList.remove('selected');
        });
        
        // Select new option
        document.querySelectorAll('.option')[optionIndex].classList.add('selected');
        
        if (updateAnswer) {
            this.userAnswers[this.currentQuestionIndex] = optionIndex;
        }
        
        this.updateQuizNavigation();
    }
    
    updateQuizNavigation() {
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitQuiz');
        
        // Previous button
        prevBtn.disabled = this.currentQuestionIndex === 0;
        
        // Next/Submit button
        const hasAnswer = this.userAnswers[this.currentQuestionIndex] !== null;
        const isLastQuestion = this.currentQuestionIndex === this.questions.length - 1;
        
        if (isLastQuestion) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
            submitBtn.disabled = !hasAnswer;
        } else {
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
            nextBtn.disabled = !hasAnswer;
        }
    }
    
    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.displayQuestion();
        }
    }
    
    nextQuestion() {
        if (this.currentQuestionIndex < this.questions.length - 1) {
            this.currentQuestionIndex++;
            this.displayQuestion();
        }
    }
    
    submitQuiz() {
        // Calculate score
        let correctAnswers = 0;
        this.questions.forEach((question, index) => {
            if (this.userAnswers[index] === question.correctAnswer) {
                correctAnswers++;
            }
        });
        
        const score = correctAnswers;
        const totalQuestions = this.questions.length;
        const percentage = Math.round((score / totalQuestions) * 100);
        
        // Display results
        this.displayResults(score, totalQuestions, percentage);
        this.showPage('resultsPage');
    }
    
    displayResults(score, total, percentage) {
        const scoreText = document.getElementById('scoreText');
        const scoreMessage = document.getElementById('scoreMessage');
        const scorePercentage = document.getElementById('scorePercentage');
        
        scoreText.textContent = `${score}/${total}`;
        scorePercentage.textContent = `${percentage}%`;
        
        // Set message based on score
        let message = '';
        if (percentage >= 90) {
            message = 'চমৎকার!';
        } else if (percentage >= 70) {
            message = 'ভালো!';
        } else if (percentage >= 50) {
            message = 'মোটামুটি!';
        } else {
            message = 'আরো চেষ্টা করুন!';
        }
        
        scoreMessage.textContent = message;
    }
    
    showAnswerReview() {
        const answerReview = document.getElementById('answerReview');
        answerReview.style.display = 'block';
        answerReview.innerHTML = '';
        
        this.questions.forEach((question, index) => {
            const userAnswer = this.userAnswers[index];
            const isCorrect = userAnswer === question.correctAnswer;
            
            const reviewElement = document.createElement('div');
            reviewElement.className = 'review-question';
            reviewElement.innerHTML = `
                <h4>প্রশ্ন ${index + 1}: ${question.question}</h4>
                <div class="review-answer">
                    <div class="review-answer-item user">
                        আপনার উত্তর: ${question.options[userAnswer]} (${String.fromCharCode(65 + userAnswer)})
                    </div>
                    <div class="review-answer-item ${isCorrect ? 'correct' : 'incorrect'}">
                        সঠিক উত্তর: ${question.options[question.correctAnswer]} (${String.fromCharCode(65 + question.correctAnswer)})
                    </div>
                </div>
            `;
            
            answerReview.appendChild(reviewElement);
        });
    }
    
    retakeQuiz() {
        this.startQuiz();
    }
    
    showError(message) {
        alert(message); // Simple error display - can be enhanced with a modal
    }
    
    showLoading() {
        document.getElementById('loadingOverlay').style.display = 'flex';
    }
    
    hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }
    
    // Reset method for starting over
    reset() {
        this.uploadedFile = null;
        this.extractedText = '';
        this.chapters = [];
        this.currentChapter = null;
        this.questions = [];
        this.currentQuestionIndex = 0;
        this.userAnswers = [];
        this.quizStartTime = null;
        
        // Reset file input
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.value = '';
        }
        
        // Clear chapter list
        const chapterList = document.getElementById('chapterList');
        if (chapterList) {
            chapterList.innerHTML = '';
        }
        
        // Clear preview content
        const previewContent = document.getElementById('previewContent');
        if (previewContent) {
            previewContent.innerHTML = '<p>একটি অধ্যায় নির্বাচন করুন</p>';
        }
        
        console.log('App reset completed');
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new BanglaEducationApp();
});

