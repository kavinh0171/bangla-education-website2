// OCR Processing Module with Tesseract.js
class OCRProcessor {
    constructor() {
        this.worker = null;
        this.isInitialized = false;
    }
    
    async initialize() {
        if (this.isInitialized) {
            return;
        }
        
        try {
            console.log('Initializing Tesseract worker...');
            this.worker = await Tesseract.createWorker('ben', 1, {
                logger: m => {
                    if (m.status === 'recognizing text') {
                        console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
                    }
                }
            });
            
            // Configure Tesseract for better Bangla recognition
            await this.worker.setParameters({
                tessedit_char_whitelist: '',
                tessedit_pageseg_mode: Tesseract.PSM.AUTO,
                preserve_interword_spaces: '1',
                tessedit_create_hocr: '0',
                tessedit_create_tsv: '0',
                tessedit_create_pdf: '0'
            });
            
            this.isInitialized = true;
            console.log('Tesseract worker initialized successfully');
        } catch (error) {
            console.error('Error initializing Tesseract:', error);
            throw new Error('OCR সিস্টেম চালু করতে সমস্যা হয়েছে।');
        }
    }
    
    async processPDF(pdf, progressCallback) {
        await this.initialize();
        
        const pdfProcessor = new PDFProcessor();
        pdfProcessor.pdf = pdf;
        
        // First, try to extract text directly from PDF
        const hasExtractableText = await pdfProcessor.hasExtractableText();
        
        if (hasExtractableText) {
            console.log('PDF has extractable text, using direct extraction');
            if (progressCallback) progressCallback(1.0);
            return await pdfProcessor.extractAllText();
        }
        
        console.log('PDF requires OCR processing');
        
        // Convert PDF pages to images
        const images = await pdfProcessor.convertPagesToImages((progress) => {
            if (progressCallback) progressCallback(progress * 0.3); // 30% for image conversion
        });
        
        // Process each image with OCR
        let fullText = '';
        const totalImages = images.length;
        
        for (let i = 0; i < totalImages; i++) {
            try {
                const canvas = images[i];
                
                // Optimize canvas for better OCR
                const optimizedCanvas = pdfProcessor.optimizeCanvasForOCR(canvas);
                
                // Perform OCR
                const result = await this.recognizeText(optimizedCanvas);
                fullText += result + '\n\n';
                
                if (progressCallback) {
                    const ocrProgress = 0.3 + ((i + 1) / totalImages) * 0.7; // 70% for OCR
                    progressCallback(ocrProgress);
                }
                
                console.log(`Processed page ${i + 1}/${totalImages}`);
            } catch (error) {
                console.error(`Error processing page ${i + 1}:`, error);
                // Continue with other pages
            }
        }
        
        return this.cleanupText(fullText);
    }
    
    async recognizeText(canvas) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        
        try {
            const result = await this.worker.recognize(canvas);
            return result.data.text;
        } catch (error) {
            console.error('Error during OCR recognition:', error);
            return '';
        }
    }
    
    cleanupText(text) {
        // Clean up OCR artifacts and improve text quality
        let cleaned = text;
        
        // Remove excessive whitespace
        cleaned = cleaned.replace(/\s+/g, ' ');
        
        // Remove isolated single characters that are likely OCR errors
        cleaned = cleaned.replace(/\s[a-zA-Z]\s/g, ' ');
        
        // Fix common OCR mistakes for Bangla text
        const corrections = {
            // Common OCR corrections for Bangla
            'ও': 'ও',
            'া': 'া',
            'ি': 'ি',
            'ী': 'ী',
            'ু': 'ু',
            'ূ': 'ূ',
            'ে': 'ে',
            'ৈ': 'ৈ',
            'ো': 'ো',
            'ৌ': 'ৌ',
            // Add more corrections as needed
        };
        
        Object.keys(corrections).forEach(wrong => {
            const correct = corrections[wrong];
            cleaned = cleaned.replace(new RegExp(wrong, 'g'), correct);
        });
        
        // Remove lines with too few characters (likely OCR noise)
        const lines = cleaned.split('\n');
        const filteredLines = lines.filter(line => {
            const trimmed = line.trim();
            return trimmed.length > 3; // Keep lines with more than 3 characters
        });
        
        cleaned = filteredLines.join('\n');
        
        // Normalize line breaks
        cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
        
        return cleaned.trim();
    }
    
    async processImage(imageElement) {
        await this.initialize();
        
        try {
            const result = await this.recognizeText(imageElement);
            return this.cleanupText(result);
        } catch (error) {
            console.error('Error processing image:', error);
            throw new Error('ছবি থেকে টেক্সট নিষ্কাশনে সমস্যা হয়েছে।');
        }
    }
    
    // Method to test OCR with a sample image
    async testOCR() {
        try {
            await this.initialize();
            
            // Create a test canvas with Bangla text
            const canvas = document.createElement('canvas');
            canvas.width = 400;
            canvas.height = 100;
            const ctx = canvas.getContext('2d');
            
            ctx.fillStyle = 'white';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = 'black';
            ctx.font = '24px Arial';
            ctx.fillText('অধ্যায় ১: পরিচয়', 50, 50);
            
            const result = await this.recognizeText(canvas);
            console.log('OCR Test Result:', result);
            
            return result.includes('অধ্যায়');
        } catch (error) {
            console.error('OCR test failed:', error);
            return false;
        }
    }
    
    // Get OCR confidence score
    async recognizeWithConfidence(canvas) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        
        try {
            const result = await this.worker.recognize(canvas);
            return {
                text: result.data.text,
                confidence: result.data.confidence,
                words: result.data.words.map(word => ({
                    text: word.text,
                    confidence: word.confidence,
                    bbox: word.bbox
                }))
            };
        } catch (error) {
            console.error('Error during OCR recognition with confidence:', error);
            return {
                text: '',
                confidence: 0,
                words: []
            };
        }
    }
    
    // Method to preprocess image for better OCR
    preprocessImage(canvas) {
        const ctx = canvas.getContext('2d');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        
        // Convert to grayscale and apply threshold
        for (let i = 0; i < data.length; i += 4) {
            const gray = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
            
            // Apply threshold for better contrast
            const threshold = 128;
            const binaryValue = gray > threshold ? 255 : 0;
            
            data[i] = binaryValue;     // Red
            data[i + 1] = binaryValue; // Green
            data[i + 2] = binaryValue; // Blue
            // Alpha remains unchanged
        }
        
        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }
    
    async terminate() {
        if (this.worker) {
            await this.worker.terminate();
            this.worker = null;
            this.isInitialized = false;
            console.log('Tesseract worker terminated');
        }
    }
    
    // Static method to check if Tesseract is available
    static isAvailable() {
        return typeof Tesseract !== 'undefined';
    }
    
    // Method to get supported languages
    static getSupportedLanguages() {
        return [
            'ben', // Bengali
            'eng', // English
            'hin', // Hindi
            'urd', // Urdu
            'ara', // Arabic
        ];
    }
}

