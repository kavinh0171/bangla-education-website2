// Language Management Module
class LanguageManager {
    constructor() {
        this.currentLanguage = 'bn'; // Default to Bangla
        this.translations = {
            bn: {
                // Header
                'site_title': 'বাংলা শিক্ষা সহায়ক',
                'site_subtitle': 'Bangla Education Helper',
                'lang_toggle': 'English',
                
                // Landing Page
                'hero_title': 'বই থেকে প্রশ্ন তৈরি করুন',
                'hero_subtitle': 'আপনার পাঠ্যবই আপলোড করুন এবং AI দিয়ে অধ্যায়ভিত্তিক প্রশ্ন তৈরি করুন',
                'upload_title': 'PDF ফাইল আপলোড করুন',
                'upload_subtitle': 'ফাইল এখানে টেনে আনুন অথবা ক্লিক করুন',
                'file_info': 'সমর্থিত ফরম্যাট: PDF | সর্বোচ্চ আকার: 50MB',
                
                // Features
                'feature_upload': 'ফাইল আপলোড',
                'feature_upload_desc': 'PDF বই সহজেই আপলোড করুন',
                'feature_ocr': 'টেক্সট নিষ্কাশন',
                'feature_ocr_desc': 'OCR দিয়ে বাংলা টেক্সট পড়ুন',
                'feature_quiz': 'প্রশ্ন তৈরি',
                'feature_quiz_desc': 'AI দিয়ে MCQ প্রশ্ন তৈরি করুন',
                
                // Processing Page
                'processing_title': 'প্রক্রিয়াকরণ চলছে...',
                'processing_pdf': 'PDF ফাইল পড়া হচ্ছে...',
                'processing_ocr': 'টেক্সট নিষ্কাশন করা হচ্ছে...',
                'processing_chapters': 'অধ্যায় খুঁজে বের করা হচ্ছে...',
                'step_pdf': 'PDF পড়া',
                'step_ocr': 'টেক্সট নিষ্কাশন',
                'step_chapters': 'অধ্যায় খোঁজা',
                'cancel_btn': 'বাতিল করুন',
                
                // Chapter Page
                'chapter_select': 'অধ্যায় নির্বাচন করুন',
                'total_chapters': 'মোট অধ্যায়:',
                'chapter_preview': 'অধ্যায়ের পূর্বরূপ',
                'select_chapter': 'একটি অধ্যায় নির্বাচন করুন',
                'generate_questions': 'প্রশ্ন তৈরি করুন',
                'preview_chapter': 'পূর্বরূপ',
                'new_file': 'নতুন ফাইল',
                
                // Quiz Generation
                'generating_questions': 'প্রশ্ন তৈরি করা হচ্ছে...',
                'selected_chapter': 'নির্বাচিত অধ্যায়:',
                'question_count': 'প্রশ্নের সংখ্যা:',
                
                // Quiz Page
                'question_number': 'প্রশ্ন',
                'previous': 'পূর্ববর্তী',
                'next': 'পরবর্তী',
                'submit': 'জমা দিন',
                
                // Results Page
                'excellent': 'চমৎকার!',
                'good': 'ভালো!',
                'average': 'মোটামুটি!',
                'try_harder': 'আরো চেষ্টা করুন!',
                'review_answers': 'উত্তর পর্যালোচনা',
                'try_again': 'আবার চেষ্টা',
                'new_chapter': 'নতুন অধ্যায়',
                'your_answer': 'আপনার উত্তর:',
                'correct_answer': 'সঠিক উত্তর:',
                
                // Footer
                'footer_text': 'বাংলা শিক্ষা সহায়ক - বিনামূল্যে শিক্ষার জন্য তৈরি',
                'technology': 'প্রযুক্তি: Tesseract.js, PDF.js, Google Gemini AI',
                
                // Error Messages
                'error_file_type': 'অনুগ্রহ করে একটি PDF ফাইল নির্বাচন করুন।',
                'error_file_size': 'ফাইলের আকার ৫০MB এর চেয়ে ছোট হতে হবে।',
                'error_processing': 'ফাইল প্রক্রিয়াকরণে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
                'error_no_chapters': 'কোনো অধ্যায় পাওয়া যায়নি। অনুগ্রহ করে নিশ্চিত করুন যে আপনার PDF ফাইলে "অধ্যায় ১", "অধ্যায় ২" ইত্যাদি শিরোনাম রয়েছে।',
                'error_question_generation': 'প্রশ্ন তৈরিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।'
            },
            en: {
                // Header
                'site_title': 'Bangla Education Helper',
                'site_subtitle': 'বাংলা শিক্ষা সহায়ক',
                'lang_toggle': 'বাংলা',
                
                // Landing Page
                'hero_title': 'Create Questions from Books',
                'hero_subtitle': 'Upload your textbooks and create chapter-wise questions using AI',
                'upload_title': 'Upload PDF File',
                'upload_subtitle': 'Drag and drop file here or click to browse',
                'file_info': 'Supported format: PDF | Max size: 50MB',
                
                // Features
                'feature_upload': 'File Upload',
                'feature_upload_desc': 'Easily upload PDF books',
                'feature_ocr': 'Text Extraction',
                'feature_ocr_desc': 'Read Bangla text with OCR',
                'feature_quiz': 'Question Generation',
                'feature_quiz_desc': 'Generate MCQ questions with AI',
                
                // Processing Page
                'processing_title': 'Processing...',
                'processing_pdf': 'Reading PDF file...',
                'processing_ocr': 'Extracting text...',
                'processing_chapters': 'Finding chapters...',
                'step_pdf': 'Reading PDF',
                'step_ocr': 'Text Extraction',
                'step_chapters': 'Finding Chapters',
                'cancel_btn': 'Cancel',
                
                // Chapter Page
                'chapter_select': 'Select Chapter',
                'total_chapters': 'Total chapters:',
                'chapter_preview': 'Chapter Preview',
                'select_chapter': 'Select a chapter to preview',
                'generate_questions': 'Generate Questions',
                'preview_chapter': 'Preview',
                'new_file': 'New File',
                
                // Quiz Generation
                'generating_questions': 'Generating Questions...',
                'selected_chapter': 'Selected Chapter:',
                'question_count': 'Number of Questions:',
                
                // Quiz Page
                'question_number': 'Question',
                'previous': 'Previous',
                'next': 'Next',
                'submit': 'Submit',
                
                // Results Page
                'excellent': 'Excellent!',
                'good': 'Good!',
                'average': 'Average!',
                'try_harder': 'Try Harder!',
                'review_answers': 'Review Answers',
                'try_again': 'Try Again',
                'new_chapter': 'New Chapter',
                'your_answer': 'Your Answer:',
                'correct_answer': 'Correct Answer:',
                
                // Footer
                'footer_text': 'Bangla Education Helper - Made for free education',
                'technology': 'Technology: Tesseract.js, PDF.js, Google Gemini AI',
                
                // Error Messages
                'error_file_type': 'Please select a PDF file.',
                'error_file_size': 'File size must be smaller than 50MB.',
                'error_processing': 'Error processing file. Please try again.',
                'error_no_chapters': 'No chapters found. Please ensure your PDF file contains chapter headings like "অধ্যায় ১", "অধ্যায় ২", etc.',
                'error_question_generation': 'Error generating questions. Please try again.'
            }
        };
    }
    
    setLanguage(language) {
        if (this.translations[language]) {
            this.currentLanguage = language;
            this.updateUI();
            this.saveLanguagePreference();
        }
    }
    
    toggleLanguage() {
        const newLanguage = this.currentLanguage === 'bn' ? 'en' : 'bn';
        this.setLanguage(newLanguage);
    }
    
    getText(key) {
        return this.translations[this.currentLanguage][key] || key;
    }
    
    updateUI() {
        // Update all elements with data-translate attribute
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            const text = this.getText(key);
            
            if (element.tagName === 'INPUT' && element.type === 'text') {
                element.placeholder = text;
            } else {
                element.textContent = text;
            }
        });
        
        // Update elements with data-bn and data-en attributes (legacy support)
        document.querySelectorAll('[data-bn][data-en]').forEach(element => {
            const text = this.currentLanguage === 'bn' ? element.dataset.bn : element.dataset.en;
            element.textContent = text;
        });
        
        // Update language toggle button
        const langBtn = document.getElementById('langToggle');
        if (langBtn) {
            langBtn.textContent = this.getText('lang_toggle');
        }
        
        // Update document language attribute
        document.documentElement.lang = this.currentLanguage;
        
        // Update font family based on language
        this.updateFontFamily();
    }
    
    updateFontFamily() {
        const body = document.body;
        if (this.currentLanguage === 'bn') {
            body.style.fontFamily = "'Noto Sans Bengali', 'Kalpurush', sans-serif";
        } else {
            body.style.fontFamily = "'Inter', 'Roboto', sans-serif";
        }
    }
    
    saveLanguagePreference() {
        try {
            localStorage.setItem('bangla-education-language', this.currentLanguage);
        } catch (error) {
            console.warn('Could not save language preference:', error);
        }
    }
    
    loadLanguagePreference() {
        try {
            const saved = localStorage.getItem('bangla-education-language');
            if (saved && this.translations[saved]) {
                this.currentLanguage = saved;
            }
        } catch (error) {
            console.warn('Could not load language preference:', error);
        }
    }
    
    init() {
        this.loadLanguagePreference();
        this.updateUI();
        
        // Set up language toggle event listener
        const langToggle = document.getElementById('langToggle');
        if (langToggle) {
            langToggle.addEventListener('click', () => this.toggleLanguage());
        }
    }
    
    // Helper method to format numbers in current language
    formatNumber(number) {
        if (this.currentLanguage === 'bn') {
            return this.convertToBanglaNumbers(number.toString());
        }
        return number.toString();
    }
    
    convertToBanglaNumbers(text) {
        const englishToBangla = {
            '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
            '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
        };
        
        return text.replace(/[0-9]/g, (match) => englishToBangla[match] || match);
    }
    
    // Helper method to get localized error messages
    getErrorMessage(errorType) {
        return this.getText(`error_${errorType}`);
    }
    
    // Helper method to get performance message based on score
    getPerformanceMessage(percentage) {
        if (percentage >= 90) {
            return this.getText('excellent');
        } else if (percentage >= 70) {
            return this.getText('good');
        } else if (percentage >= 50) {
            return this.getText('average');
        } else {
            return this.getText('try_harder');
        }
    }
    
    // Method to add new translations dynamically
    addTranslation(language, key, value) {
        if (!this.translations[language]) {
            this.translations[language] = {};
        }
        this.translations[language][key] = value;
    }
    
    // Method to get current language
    getCurrentLanguage() {
        return this.currentLanguage;
    }
    
    // Method to check if a language is supported
    isLanguageSupported(language) {
        return !!this.translations[language];
    }
    
    // Method to get all supported languages
    getSupportedLanguages() {
        return Object.keys(this.translations);
    }
}

// Initialize language manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.languageManager = new LanguageManager();
    window.languageManager.init();
});

